There are two types of communicating method, the TCP and the WebSocket.

This project initially used TCP connections, but there were lots of drawbacks,
then it was replaced by WebSocket.
