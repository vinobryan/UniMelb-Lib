COMP30022 IT Project
Semester 2 2017
House Tarth
Catch Me If You Can

Application Readme:
\CatchMeIfYouCan\README.md

Server Readme:
\Server Program\README.md
\Server Program\Node.JS Web Socket Connection\README.md
