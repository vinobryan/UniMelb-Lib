
/**
 * This class should be used to restrict the game's view to a subset of the entire world.
 * 
 * You are free to make ANY modifications you see fit.
 * These classes are provided simply as a starting point. You are not strictly required to use them.
 */
public class Camera {

	public float getLeft() {
		// You probably want to change this.
		return 0;
	}
	public float getTop() {
		// You probably want to change this.
		return 0;
	}
	public float getRight() {
		// You probably want to change this.
		return 0;
	}
	public float getBottom() {
		// You probably want to change this.
		return 0;
	}
}
