module LW where

example :: Int

example =
	let a = 1
	in a + b
	where b = 2
