package tiles;

import world.Car;

public class GrassTrap extends TrapTile {
	public void applyTo(Car car, float delta) {
		// car.setVelocity(1f, 1f);
	}

}
