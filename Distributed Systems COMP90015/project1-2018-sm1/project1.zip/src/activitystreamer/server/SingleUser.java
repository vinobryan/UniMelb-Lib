package activitystreamer.server;

import activitystreamer.util.Settings;

public 	class SingleUser{
	private String username;
	protected String secret;

	public SingleUser(String username, String secret) {
		this.username = username;
		this.secret = secret;
	}

	/** Get user's user name
	 * @return
	 */
	public String getUsername() {
		return username;
	}
	
	/** Set user's user name
	 * @param username
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	
	/** Get user's secret
	 * @return
	 */
	public String getSecret() {
		return secret;
	}
	
	/** Set user's secret
	 * @param secret
	 */
	public void setSecret(String secret) {
		this.secret = secret;
	}
	
	/** Whether this user is anonymous
	 * @return
	 */
	public boolean isAnonymous() {
		return this.username.equals(Settings.ANONYMOUS);
	}
	
	/** Whether 2 users are identical
	 * @param u
	 * @return
	 */
	public boolean isSame(SingleUser u) {
		if (u.getUsername().equals(this.username) && u.getSecret().equals(this.secret)) {
			return true;
		}else {
			return false;
		}
	}
}
